# game-website
My game website. More games coming soon so keep checking for updates!
## How to host unblocked versions ##
Go to a site that can host HTML and can support HTML 5. Some popular ones are Google Apps Script (Just copying the code and writing a doGet function) and Google Sites (embeding HTML code)
